classdef NaiveKAF
    % NaiveKAF uses the Gaussian RBF kernel to predict observations
    % from state data
    
    properties % Public
        %%% Could add some automatic type and range error checking    

        %%% Kernel data

        kernel          % Kernel object
        stateDim        % Ambient dimension of states
        
        %%% KAF data

        numTrain            % Number of training points
        
        stateData           % Store the training data =(
        subspace            % KPCA subspace (numTrain x approxRank) 
        eigvals             % KPCA eigenvalues (approxRank x 1)
    end
    
    properties (Access = private)
                
        approxRank        % Truncation level

    end
    
    methods
        function [obj] = NaiveKAF(kernel, stateData, approxRank)
            % obj = NaiveKAF(kernel, stateData, approxRank)
            %       Initializes KAF by solving a KPCA problem
            %       Stores information needed to build models for
            %       specific observables.
            
            obj.kernel = kernel;
            obj.stateDim = kernel.stateDim;
            
            if (obj.stateDim ~= size(stateData,1))
                error( 'Feature map and state dimension do not match' );
            end
            
            obj.stateData = stateData;
            
            %%% Form full kernel matrix
            
            KXX = KernelMatrix(obj.kernel, stateData, stateData);

            %%% Perform KPCA on kernel matrix via eigs
            
            [obj.subspace, Lambda] = eigs(KXX, approxRank);
            
            obj.eigvals = diag(Lambda);
            
            obj.approxRank = length(obj.eigvals);
  
            %%% Filter eigenvalues
            %%% lambda -> lambda + (small constant)
            %%% Implements a type of ridge regression
            
            obj.eigvals = obj.eigvals + max(obj.eigvals) * 1e-6;
            
            %%% Optional: Plot spectrum and filtered spectrum
            
            %semilogy(obj.eigvals); hold on
            % semilogy(Lambda);
        end
    end
end

