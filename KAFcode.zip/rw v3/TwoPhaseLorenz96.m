function [data] = TwoPhaseLorenz96(n, dt, y0, F)
%   TwoPhaseLorenz96 and L96fcn generate data from a trajectory of the two-phase Lorenz 96
%   dynamical system
%   n = number of samples
%   dt = time discretization for ode45
%   ICs = initial condition
%   Model parameters are hard-coded in function


%%Parameters (Default Parameters: K = 9, J = 8, eps = 1/128, hx = -.8, hy = 1)

K=size(y0,1); 
J=size(y0,2)-1; 
eps=1/128; 
hx = -.8; 
hy = 1;  


t=0:dt:ceil(n*dt);
OPTs = odeset('reltol', 1e-6, 'abstol', 1e-8);

[time, fOUT]=ode45(@(t, y) L96fcn(t,y,K,J,eps,hx,hy,F), t, y0, OPTs);

X = fOUT';

data = X(:,1:n);

end