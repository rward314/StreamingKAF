classdef ScalableKAF
    % ScalableKAF uses random features to perform dual KPCA on state data
    % This prepares us to build forecast models for observables
    
    properties % Public
        %%% Could add some automatic type and range error checking    

        %%% RFF data
        
        featMap         % Random feature map
        stateDim        % Ambient dimension of states
        numFeat         % Number of random features

        %%% ScalableKAF data
        
        stateData           % Maintain a copy of the state data
        subspace            % Dual KPCA subspace (numFeat x approxRank) 
        eigvals             % Dual KPCA eigenvalues (numFeat x 1)
    end
    
    properties (Access = private)
        
        %%% Nystrom parameters
        
        approxRank        % Truncation level
        passes            % Number of passes
    end
    
    methods
        function [obj] = ScalableKAF(featMap, stateData, approxRank, passes)
            % obj = ScalableKAF(featMap, stateData, approxRank, passes)
            %       Initializes KAF by solving a dual KPCA problem
            %       Stores information needed to build models for
            %       specific observables.
            
            obj.featMap = featMap;
            obj.stateDim = featMap.stateDim;
            obj.numFeat = featMap.numFeat;
            
            if (obj.stateDim ~= size(stateData,1))
                error( 'Feature map and state dimension do not match' );
            end
            
            obj.stateData = stateData;
            
            %%% Perform (dual) KPCA on covariance of features
            
            %%% Truncated eigenvalue decomposition of
            %%% phi(stateData) * phi(stateData)'
            %%% via randomized Nystrom approximation            
            
            [obj.subspace, Lambda] = FeatNystrom(obj.featMap, stateData, approxRank, passes);

            obj.eigvals = diag(Lambda);
            
            obj.approxRank = length(obj.eigvals);
            obj.passes = passes;

            %%% Filter eigenvalues
            %%% lambda -> lambda + (small constant)
            %%% Implements a type of ridge regression
            
             obj.eigvals = obj.eigvals + max(obj.eigvals) * 1e-6;
            
            %%% Optional: Plot spectrum and filtered spectrum
            
            %semilogy(obj.eigvals); hold on
            % semilogy(Lambda);
        end
    end
end

