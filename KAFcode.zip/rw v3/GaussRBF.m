classdef GaussRBF
    % GaussRBF class implements the Gaussian RBF kernel
        
    properties  % Public
        % Can add type and range error checking
        
        bandwidth        % Bandwidth of RBF kernel (positive)
        stateDim         % Dimension of RBF kernel (natural number)
    end

    methods
        function obj = GaussRBF(bandwidth, stateDim)
            % obj = GaussRBF(bandwidth, stateDim, numFeat)
            %    Construct a Gauss RBF kernel
            
            obj.bandwidth = bandwidth;
            obj.stateDim = stateDim;
        end
        
        function KXY = KernelMatrix(obj, X, Y)
            % KXY = KernelMatrix(obj, X, Y)
            %    Computes kernel matrix of the columns of X and Y
            %    KXY is numcols(X) x numcols(Y)
            
            %%% Error checking
            
            if (obj.stateDim ~= size(X, 1) || obj.stateDim ~= size(Y, 1) )
                error( 'States have incorrect dimension' )
            end
            
            %%% Compute kernel matrix
            
            Krows = size(X,2);
            Kcols = size(Y,2);
            KXY = zeros( Krows, Kcols );
            
            for i = 1:Krows
                for j = 1:Kcols
                    KXY(i, j) = exp( - obj.bandwidth * norm(X(:,i) - Y(:,j),2)^2 );
                end
            end

        end
    end
end