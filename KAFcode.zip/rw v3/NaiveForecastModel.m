classdef NaiveForecastModel
    % NaiveForecastModel uses a NaiveKAF + observable data to construct a
    % nonlinear forecasting model
    
    properties
        kernel              % kernel
        
        stateData           % State data
        stateDim            % State dimension
        
        obsDim              % Dimension of observable
        forecastWeights     % Weight matrix (obsDim x numFeat)
    end
    
    methods
        function [obj] = NaiveForecastModel(myKAF, obsData)
            % ForecastModel(myKAF, obsData)
            %   Uses the NaiveKAF + observable data to construct a
            %   nonlinear forecasting model
    
            % Error checking
            
            if (size(myKAF.stateData, 2) ~= size(obsData, 2))
                error( 'Mismatch in number of states and observable values' );
            end

            %%% Initialization
            
            obj.kernel = myKAF.kernel;
            
            obj.stateData = myKAF.stateData;
            obj.stateDim = myKAF.stateDim;

            obj.obsDim = size(obsData, 1);
            
            %%% Compute forecast weights (cf. Sec 3.3)
            %%% Note: Use of pinv is not best practice
            
            obj.forecastWeights = ((obsData * myKAF.subspace) * pinv(diag(myKAF.eigvals))) * myKAF.subspace';
        end
        
        function [obsEst] = NaiveForecast(obj, testData)
            % obsEst = NaiveForecast(obj, obsData)
            
            %%% Error checking

            if (obj.stateDim ~= size(testData, 1))
                error( 'Test states have incorrect dimension' );
            end
            
            %%% Estimate observable from data via product W * KXY
            %%% Output dimension: obsDim x numcols(stateData)
            
            KXY = KernelMatrix( obj.kernel, obj.stateData, testData );
            obsEst = obj.forecastWeights * KXY;
        end
    end
end

