function pospart = subplus(x)
    % pospart = subplus(x)
    %    Returns positive part of an array of real numbers
    
    pospart = max(x, 0);
end