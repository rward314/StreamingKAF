clear all

% DRIVER runs some experiments to test scalable kernel analog forecasting
% as plotted in paper ``Learning to Forecast Dynamical Systems from Streaming Data"


SCALABLE = true;
FULL = false;

DISPLAY = true;

LORENZ63 = true;  %Classic Lorenz63 system
LORENZ96 = false;   %Two-phase Lorenz96 system

%%% Generate some trajectory data

n = 10000;       % Number of training points
m = 10000;       % Number of test points

dt = .01;  % time discretization for dynamical system
          
%%% Setup for forecasting experiments...

NumTestTrials = 5;              % Number of testing trials
NumStates = 1;                  % Number of states to forecast, from 1 to stateDim
bandwidth = .01;               % Bandwidth (gamma) of Gaussian kernel
numFeat = ceil(sqrt(n)*log(n)); % Number of random features 

approxRank = 400;               % Rank of approximation
passes = 1;                     % Number of passes over data
q = 50;                      % Forecasting time (q*dt seconds)

TrainTimeScalable_init = 0;
TrainTimeScalable = 0;
TestTimeScalable = 0;

TrainTimeFull_init = 0;
TrainTimeFull = 0;
TestTimeFull = 0;

errScalable = zeros(NumTestTrials,1);
errFull = zeros(NumTestTrials,1);

if LORENZ96
     K=9;        %System dimensions.  
     J=8;
     F = 6.9;     % F is Forcing constant for two-phase Lorenz96.  
                 % When K=9 and J = 8,
                 % F = 5 yeilds periodic system, 
                 % F = 6.9 yields quasi-periodic,
                 % F = 10 is chaotic

end

%generate training data
if LORENZ63
  X = Lorenz63(n+ q, dt, [1,1,1]);
  y0 = X(:,end);
end

if LORENZ96
    
  %Burn-in for initialization to get to a point on the attractor
  y1 = randn(K,J+1);
  X_temp = TwoPhaseLorenz96(1000, dt, y1,F);  
  %%%%%%%
  
  %generate training data
  y1 = reshape(X_temp(:,end),[K,J+1]);
  X_full = TwoPhaseLorenz96(n+ q, dt, y1, F);
  
  %initial point for testing is final point of training
  y0 = reshape(X_full(:,end),[K,J+1]);
  
  %use only first K slow variables for training
  X = X_full(1:K,:);

end


stateDim = size(X, 1);             % Ambient dimension of training states


%%% Prepare for KAF by constructing kernel / feature map
%%% and solving dual KPCA problem

tic
if SCALABLE
    featMap = RFF(bandwidth, stateDim, numFeat);
    nysKAF = ScalableKAF(featMap, X(:,1:n), approxRank, passes);
end
TrainTimeScalable_init = TrainTimeScalable_init + toc;

tic
if FULL
    kernel = GaussRBF(bandwidth, stateDim);
    baseKAF = NaiveKAF(kernel, X(:,1:n), approxRank);
end
TrainTimeFull_init = TrainTimeFull_init + toc;

%%% Test NumTestTrials different testing sets

for j=1:NumTestTrials

%%% Generate new test data at random IC 

if LORENZ63
   Y = Lorenz63(m + q, dt, y0);
   y0 = Y(:,end);
end

if LORENZ96
  Y_full = TwoPhaseLorenz96(m + q, dt, y1, F);
  y1 = reshape(Y_full(:,end),[K,J+1]);
  Y = Y_full(1:K,:);
end


%%% Generate an observable by lagging data 
Xq = X(1:NumStates, q+1:q+n);               % Shift data left

%%% Generate lagged test data for comparison
Yq = Y(1:NumStates, q+1:q+m);               % Shift data left

    
Yvec = reshape(Yq, [NumStates * m, 1]);
testNorm = std(Yvec);
    

% Scalable KAF
if SCALABLE
    
   tic
   myModel = ForecastModel(nysKAF, Xq); 
   TrainTimeScalable = TrainTimeScalable+ toc;
  
   tic
   myForecast = Forecast(myModel, Y(:,1:m));   

   TestTimeScalable = TestTimeScalable + toc;


   errScalable(j,1) = norm(myForecast(1,:) - Yq(1,:))/(sqrt(m)*testNorm);      %Normalized RMSE error for first State
end

% Full kernel approximation
if FULL 
    tic
   baseModel = NaiveForecastModel(baseKAF, Xq);
       TrainTimeFull = TrainTimeFull + toc;
   
   tic
   baseForecast = NaiveForecast(baseModel, Y(:,1:m));
       TestTimeFull = TestTimeFull + toc;

   
   errFull(j,1) = norm(baseForecast(1,:) - Yq(1,:))/(sqrt(m)*testNorm);       %Normalized RMSE error for first State
end


end

if SCALABLE 
  muScalable = mean(errScalable);
  standevScalable = std(errScalable);
  
  TrainTimeScalable = TrainTimeScalable/NumTestTrials;
  TestTimeScalable = TestTimeScalable/NumTestTrials;
  
  TrainTimeScalable = TrainTimeScalable + TrainTimeScalable_init;
  
end

if FULL 
  muFull = mean(errFull);
  standevFull = std(errFull);
  
  TrainTimeFull = TrainTimeFull/NumTestTrials;
  TestTimeFull = TestTimeFull/NumTestTrials;
  
  TrainTimeFull = TrainTimeFull + TrainTimeFull_init;
end


if DISPLAY
 
    if SCALABLE 
    fprintf('Given n=%i training samples and m=%i testing samples \n', n,m)
    fprintf('and forecasting horizon %4.4f seconds, \n', q*dt)
    fprintf('the average normalized RMSE forecasting error for SCALABLE KAF is %4.4f with standard deviation %4.4f \n', muScalable, standevScalable)

    fprintf('and the training time is %4.4f seconds and the testing time is %4.4f seconds \n', TrainTimeScalable, TestTimeScalable)
    end
fprintf('\n');

    if FULL
    fprintf('For %i training samples and %i testing samples \n', n,m)
    fprintf('and forecasting horizon %4.4f seconds, \n', q*dt)
    fprintf('the average normalized RMSE forecasting error for NAIVE KAF is %4.4f with standard deviation %4.4f \n', muFull, standevFull)
    
    fprintf('and the training time is %4.4f seconds and the testing time is %4.4f seconds ... \n', TrainTimeFull, TestTimeFull)
    end

end


