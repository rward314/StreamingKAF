function dydt = L96fcn(t,y,K,J,eps,hx,hy,F)
% L96fcn computes dydt = F(y) 
%   where F is the discrete evoluation map for the two-phase Lorenz96 system
%   with parameters eps, hx, hy, F, K, J and periodic boundary conditions: 
%   X_{k+K} = X_k, Y_{j, k+K} = Y_{j+J, k},  Y_{j+J,k} = Y_{j,k+1}

y = reshape(y,[K,J+1]); 
dydt = zeros(K,J+1);

%%% slow variables are first column of matrix of variables %%%%%


dydt(1,1) = -y(K,1)*(y(K-1,1) - y(2,1)) - y(1,1) + F + (hx/J)*sum(y(1,2:J+1));

dydt(2,1) = -y(1,1)*(y(K,1) - y(3,1)) - y(2,1) + F + (hx/J)*sum(y(2,2:J+1));

for i=3:K-1
dydt(i,1) = -y(i-1,1)*(y(i-2,1) - y(i+1,1)) - y(i,1) + F + (hx/J)*sum(y(i,2:J+1));
end

dydt(K,1) = -y(K-1,1)*(y(K-2,1) - y(1,1)) - y(K,1) + F + (hx/J)*sum(y(K,2:J+1));
%%%%%%%


%%%%% fast variables are 2:J+1 columns %%%%%

%i=1,j=1
dydt(1,2) = (1/eps)*(-y(1,3)*(y(1,4) - y(K,J+1)) - y(1,2) + hy*y(1,1));

%i=2,..,K, j = 1
for i=2:K       
    dydt(i,2) = (1/eps)*(-y(i,3)*(y(i,4) - y(i-1,J+1)) - y(i,2) + hy*y(i,1));        
end  

%j in 2, ..., J-2
for j=2:J-2    
    for i=1:K       
            dydt(i,j+1) = (1/eps)*(-y(i,j+2)*(y(i,j+3) - y(i,j)) - y(i,j+1) + hy*y(i,1));        
    end    
end

%j = J-1, i = 1,...,K-1
 for i=1:K-1       
        dydt(i,J) = (1/eps)*(-y(i,J+1)*(y(i+1,2) - y(i,J-1)) - y(i,J) + hy*y(i,1));        
 end 

 %j = J-1, i = K
 dydt(K,J) = (1/eps)*(-y(K,J+1)*(y(1,2) - y(K,J-1)) - y(K,J) + hy*y(K,1)); 
 
 %j = J, i = 1,...,K-1
 for i=1:K-1       
        dydt(i,J+1) = (1/eps)*(-y(i+1,2)*(y(i+1,3) - y(i,J)) - y(i,J+1) + hy*y(i,1));        
 end 
 
 %j = J, i = K
 dydt(K,J+1) = (1/eps)*(-y(1,2)*(y(1,3) - y(K,J)) - y(K,J+1) + hy*y(K,1));  



%%%%%%

y = reshape(y,[K*(J+1),1]);
dydt = reshape(dydt,[K*(J+1),1]);

end