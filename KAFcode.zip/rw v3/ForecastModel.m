classdef ForecastModel
    % ForecastModel uses a ScalableKAF + observable data to construct a
    % nonlinear forecasting model
    
    properties
        featMap             % Random feature map
        numFeat             % Number of random features
        
        stateDim            % State dimension
        obsDim              % Dimension of observable
        forecastWeights     % Weight matrix (obsDim x numFeat)
    end
    
    methods
        function [obj] = ForecastModel(myKAF, obsData)
            % ForecastModel(myKAF, obsData)
            %   Uses the ScalableKAF + observable data to construct a
            %   nonlinear forecasting model
    
            % Error checking
            
            if (size(myKAF.stateData, 2) ~= size(obsData, 2))
                error( 'Mismatch in number of states and observable values' );
            end

            %%% Initialization
            
            obj.featMap = myKAF.featMap;
            obj.numFeat = myKAF.numFeat;
            
            obj.stateDim = myKAF.stateDim;
            obj.obsDim = size(obsData, 1);
 
            obj.forecastWeights = zeros(obj.obsDim, obj.numFeat);
                                  
            %%% Form product Observable * phi(stateData)'
            
            C = RMultT(obj.featMap, myKAF.stateData, obsData);
            
            %%% Compute forecast weights (cf. Sec 3.3)
            %%% Note: Use of pinv is not best practice
            
            obj.forecastWeights = ((C * myKAF.subspace) * pinv(diag(myKAF.eigvals))) * myKAF.subspace';
            
        end
        
        function [obsEst] = Forecast(obj, testData)
            % obsEst = Forecast(obj, obsData)
            
            %%% Error checking

            if (obj.stateDim ~= size(testData, 1))
                error( 'Test states have incorrect dimension' );
            end
            
            %%% Estimate observable from data via product weights * phi(stateData)
            %%% Output dimension: obsDim x numcols(stateData)
                        
            obsEst = RMult(obj.featMap, testData, obj.forecastWeights);
        end
    end
end

