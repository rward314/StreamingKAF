function [Q, Lambda] = FeatNystrom(featMap, stateData, approxRank, passes)
% FeatNystrom(featMap, stateData, approxRank, passes)
%      Computes a truncated eigenvalue decomposition
%      of featurized data by streaming over the columns

actualRank = min(approxRank, featMap.numFeat);
subspaceDim = min(2*approxRank, featMap.numFeat);

Z = randn( featMap.numFeat, subspaceDim );      % Random subspace, oversample by 2x

for i = 1:passes
    [Q, ~] = qr(Z, 0);                      % Orthogonalize columns
    Z = MultCov(featMap, stateData, Q);     % Form phi(stateData)*phi(stateData)'*Q in one pass
end

C = Q' * Z;               % Core matrix
C = (C + C')/2;           % Symmetrize
[U, D] = eig(C);          % Compute dense eigenvalue decomposition

D = sqrt(subplus(D));     % Take (positive) square root

%%% Optional: Threshold or zero out very small values
%%% May require further study

% dd = diag(D);
% thresh = eps( max(dd) );
% D = diag( max(dd, thresh) );

%%% Compute square root of Nystrom approximation
%%% Note: Use of pinv is not best practice

nystromSqrt = (Z * U) * pinv(D);

%%% Form dense SVD to pass to eigenvalue decomposition of Nystrom approx

[Q, Sigma, ~] = svd(nystromSqrt);

Q = Q(:, 1:actualRank);
Lambda = Sigma(1:actualRank, 1:actualRank) .^ 2;

end

