function [data] = Lorenz63(n, dt, ICs)
% LORENZ63 generates trajectory of the Lorenz63 dynamical system
%   n = number of samples
%   dt = time discretization for ode45
%   ICs = initial condition
%   Model parameters are hard-coded in function

sigma=10; beta=8/3; ro=28;  % model parameters
t=0:dt:ceil(n*dt);
OPTs = odeset('reltol', 1e-6, 'abstol', 1e-8);
[time, fOUT]=ode45(@(t, x)([-sigma*x(1)+sigma*x(2);  -x(2)-x(1).*x(3); -beta*x(3)+x(1).*x(2)-beta*ro]), t, ICs, OPTs);

F = fOUT';

data = F(:,1:n);

end

