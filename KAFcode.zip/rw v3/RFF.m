classdef RFF
    % RFF class is a random feature map for Gaussian RBF kernel
    
    properties  % Public
        % Can add type and range error checking
        
        bandwidth        % Bandwidth of RBF kernel (positive)
        stateDim         % Dimension of RBF kernel (natural number)
        numFeat          % Number of random features (natural number)
    end
    
    properties  (Access = private)
        blockSize = 1000;     % Size of blocks for matrix multiplication
        
        featDir        % Random feature descriptor matrix (numFeat x stateDim)
        featShift      % Random shifts (numFeat x 1)
    end
    
    methods
        function obj = RFF(bandwidth, stateDim, numFeat)
            % obj = RFF(bandwidth, stateDim, numFeat)
            %    Construct a random feature map
            
            obj.bandwidth = bandwidth;
            obj.stateDim = stateDim;
            obj.numFeat = numFeat;
            
            obj.featDir = sqrt(2*bandwidth) * randn(numFeat, stateDim);     % CHECK SCALING!
            obj.featShift = 2 * pi * rand(numFeat, 1);
        end
        
        function phiX = Featurize(obj, stateData)
            % phiX = Featurize(obj, stateData)
            %    Computes features of the columns of stateData
            %    phiX is numFeat x numcols(stateData)
            
            %%% Error checking
            
            if (obj.stateDim ~= size(stateData, 1))
                error( 'States have incorrect dimension' )
            end
            
            %%% Compute random features
            
            phiX = obj.featDir * stateData;
            phiX = phiX + obj.featShift * ones(1, size(stateData, 2));
            phiX = sqrt(2 / obj.numFeat) * cos(phiX);
        end
        
        function CM = MultCov(obj, stateData, M)
            % CM = MultCov(obj, stateData, M)
            %    Forms phi(stateData) * phi(stateData)' * M
            %    in one pass over columns of stateData
            %    CM is numFeat x numcols(M)
            
            %%% Error checking
            
            if (obj.numFeat ~= size(M,1))
                error( 'MultCov dimension mismatch' );
            end
                       
            %%% Compute product by one pass over the columns
            %%% For better efficiency, we block columns
 
            CM = zeros(obj.numFeat, size(M, 2));
            
            numStates = size(stateData,2);
            numBlocks = ceil( numStates / obj.blockSize );
            
            for j = 1:numBlocks
                blockStart = 1 + (j - 1) * obj.blockSize;
                blockEnd = min(j * obj.blockSize, numStates);
                
                phiX = Featurize(obj, stateData(:, blockStart:blockEnd));
                CM = CM + phiX * (phiX' * M);
            end
        end
        
        function MPhiT = RMultT(obj, stateData, M)
            % MPhiT = RMultT(obj, stateData, M)
            %     Forms M * phi(stateData)' in one pass over
            %     the columns of stateData
            %     MPhiT is numrows(M) x numFeat
            
            %%% Error checking
            if (size(M,2) ~= size(stateData,2))
                error( 'RMultT dimension mismatch' );
            end

            %%% Compute product by one pass over the columns
            %%% For better efficiency, we block columns

            MPhiT = zeros(size(M,1), obj.numFeat);
            
            numStates = size(stateData,2);
            numBlocks = ceil( numStates / obj.blockSize );
            
            for j = 1:numBlocks
                blockStart = 1 + (j - 1) * obj.blockSize;
                blockEnd = min(j * obj.blockSize, numStates);

                phiX = Featurize(obj, stateData(:, blockStart:blockEnd));
                MPhiT = MPhiT + M(:, blockStart:blockEnd) * phiX';
            end
        end
        
        function MPhi = RMult(obj, stateData, M)
            % MPhi = RMult(obj, stateData, M)
            %     Forms M * phi(stateData) in one pass over
            %     the columns of stateData
            %     MPhi is numrows(M) x numcols(stateData)
            
            %%% Error checking
            if (obj.numFeat ~= size(M,2))
                error( 'RMult dimension mismatch' );
            end

            %%% Compute product by one pass over the columns
            %%% For better efficiency, we block columns
            
            MPhi = zeros(size(M,1), size(stateData,2));
 
            numStates = size(stateData,2);
            numBlocks = ceil( numStates / obj.blockSize );
            
            for j = 1:numBlocks
                blockStart = 1 + (j - 1) * obj.blockSize;
                blockEnd = min(j * obj.blockSize, numStates);

                phiX = Featurize(obj, stateData(:, blockStart:blockEnd));
                MPhi(:, blockStart:blockEnd) = M * phiX;
            end
        end
    end
end

